## 1.0.1 / 2017-07-24

* [ENHANCEMENT] Add exporter instrumentation [#78]
* [BUGFIX] Exclude basic auth credentials from log [#71]
* [BUGFIX] Fix missing node store size metric
## 1.0.0 / 2017-07-03

* [ENHANCEMENT] Rewrite the codebase to reduce redundancy and improve extensibility [#65]
* [ENHANCEMENT] Add examples for Grafana and Prometheus [#66]
* [BREAKING] Removed several duplicate or redundant metrics [#65]
